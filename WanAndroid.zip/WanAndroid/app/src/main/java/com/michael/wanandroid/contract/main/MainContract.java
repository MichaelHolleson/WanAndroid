package com.michael.wanandroid.contract.main;

public interface MainContract {

    interface MainPresenter{

    }

    interface MainView {

    }

}
