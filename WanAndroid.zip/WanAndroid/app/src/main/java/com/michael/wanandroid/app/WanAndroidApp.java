package com.michael.wanandroid.app;

import android.app.Application;

public class WanAndroidApp extends Application {



}
