package com.michael.wanandroid.ui.activity;

import com.michael.wanandroid.base.BaseActivity;

public class SettingActivity extends BaseActivity {
    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
