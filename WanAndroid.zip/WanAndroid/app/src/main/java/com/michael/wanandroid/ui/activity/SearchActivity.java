package com.michael.wanandroid.ui.activity;

import com.michael.wanandroid.base.BaseActivity;

public class SearchActivity extends BaseActivity {
    @Override
    protected void initView() {

    }

    @Override
    protected void initData() {

    }
}
