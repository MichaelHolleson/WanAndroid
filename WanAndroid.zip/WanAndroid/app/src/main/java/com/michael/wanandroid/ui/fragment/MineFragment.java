package com.michael.wanandroid.ui.fragment;

import com.michael.wanandroid.base.BaseFragment;

public class MineFragment extends BaseFragment {


    @Override
    public void initView() {

    }

    @Override
    public void initData() {

    }
}
